<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php $__env->startSection('pageTitle'); ?><?php echo $__env->yieldSection(); ?></title>
    <!-- Styles -->
    <link href="<?php echo e(asset('asset/css/sb-admin-2.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('asset/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('asset/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">

</head>
<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text mx-3">SWM <sup>Portal</sup></div>
        </a>

        <!-- Divider -->
        <hr class="sidebar-divider my-0">

        <!-- Nav Item - Dashboard -->
        <li class="nav-item <?php $__env->startSection('dashboard'); ?>  <?php echo $__env->yieldSection(); ?>">
            <a class="nav-link" href="<?php echo e(route('home')); ?>">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span><?php echo e(__('messages.dashboard')); ?></span></a>
        </li>

        <li class="nav-item ">
            <a class="nav-link" href="#">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span><?php echo e(__('messages.hosting')); ?></span></a>
        </li>

        <li class="nav-item ">
            <a class="nav-link" href="#">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span><?php echo e(__('messages.vps')); ?></span></a>
        </li>

        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item <?php $__env->startSection('domain'); ?>  <?php echo $__env->yieldSection(); ?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                <i class="fas fa-fw fa-cog"></i>
                <span><?php echo e(__('messages.domainservice')); ?></span>
            </a>
            <div id="collapseTwo" class="collapse <?php $__env->startSection('domainshow'); ?>  <?php echo $__env->yieldSection(); ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item <?php $__env->startSection('domainall'); ?>  <?php echo $__env->yieldSection(); ?>" href="<?php echo e(route('domain.all')); ?>"><?php echo e(__('messages.mydomain')); ?></a>
                    <h6 class="collapse-header"><?php echo e(__('messages.domaingo')); ?></h6>
                    <a class="collapse-item" href="#"><?php echo e(__('messages.checkdomain')); ?></a>
                    <a class="collapse-item" href="#"><?php echo e(__('messages.regdomain')); ?></a>
                    <a class="collapse-item" href="#"><?php echo e(__('messages.tranfdomain')); ?></a>
                    <h6 class="collapse-header"><?php echo e(__('messages.domainth')); ?></h6>
                    <a class="collapse-item" href="<?php echo e(route('check.th')); ?>"><?php echo e(__('messages.checkdomainth')); ?></a>
                    <a class="collapse-item" href="#"><?php echo e(__('messages.regdomainth')); ?></a>
                    <a class="collapse-item" href="#"><?php echo e(__('messages.tranfdomainth')); ?></a>
                </div>
            </div>
        </li>

        <li class="nav-item ">
            <a class="nav-link" href="#">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span><?php echo e(__('messages.invoice')); ?></span></a>
        </li>
        <!-- Nav Item - Tables -->
        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#ticket" aria-expanded="true" aria-controls="collapseTwo">
                <i class="fas fa-fw fa-cog"></i>
                <span><?php echo e(__('messages.ticket')); ?></span>
            </a>
            <div id="ticket" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item" href="#"><?php echo e(__('messages.openticket')); ?></a>
                    <a class="collapse-item" href="#"><?php echo e(__('messages.histicket')); ?></a>
                </div>
            </div>
        </li>

        <li class="nav-item ">
            <a class="nav-link" href="#">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span><?php echo e(__('messages.payment')); ?></span></a>
        </li>
        <li class="nav-item ">
            <a class="nav-link" href="#">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span><?php echo e(__('messages.howto')); ?></span></a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider d-none d-md-block">

        <!-- Sidebar Toggler (Sidebar) -->
        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>

                <!-- Topbar Navbar -->
                <ul class="navbar-nav ml-auto">


                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="lang" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                                <?php echo e(__('messages.credit')); ?> <?php echo e(Auth::user()->credit); ?> ฿
                            </span>
                        </a>
                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="lang">
                            <a class="dropdown-item" href="#" ><?php echo e(__('messages.addcoin')); ?></a>
                        </div>
                    </li>

                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="lang" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                              <?php if( app()->getLocale()  == "th"): ?>
                                    <img class="img-profile rounded-circle" src="<?php echo e(asset('img/flag/th.png')); ?> ">  ไทย
                                <?php elseif( app()->getLocale()  == "en"): ?>
                                    <img class="img-profile rounded-circle" src="<?php echo e(asset('img/flag/us.png')); ?> ">   English
                                <?php endif; ?>
                            </span>
                        </a>
                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="lang">
                            <a class="dropdown-item" href="<?php echo e(url('locale/en')); ?>" ><img src="<?php echo e(asset('img/flag/us.png')); ?> "> English</a>
                            <a class="dropdown-item" href="<?php echo e(url('locale/th')); ?>" ><img src="<?php echo e(asset('img/flag/th.png')); ?> "> ไทย</a>
                        </div>
                    </li>

                    <!-- Nav Item - User Information -->
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e(Auth::user()->name); ?></span>
                            <img class="img-profile rounded-circle" src="<?php echo e(Auth::user()->avatar); ?>">
                        </a>
                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                            <a class="dropdown-item" href="#">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                <?php echo e(__('messages.profile')); ?>

                            </a>
                            <a class="dropdown-item" href="#">
                                <i class="fas fa-key fa-sm fa-fw mr-2 text-gray-400"></i>
                                <?php echo e(__('messages.changpass')); ?>

                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();  document.getElementById('logout-form').submit();">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                <?php echo e(__('messages.logout')); ?>

                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                    <!-- Nav Item - User Information -->
                </ul>

            </nav>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Your Website 2019</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('asset/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/vendor/bootstrap/js/bootstrap.bundle.min.js' )); ?>"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('asset/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('asset/js/sb-admin-2.min.js')); ?>"></script>

    <!-- Page level plugins -->
    <script src="<?php echo e(asset('asset/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('asset/js/demo/datatables-demo.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweetalert.min.js')); ?> "></script>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
