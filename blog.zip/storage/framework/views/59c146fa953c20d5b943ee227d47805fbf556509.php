<?php $__env->startSection('pageTitle'); ?><?php echo e(__('messages.login')); ?> ##parent-placeholder-6b4ea802132b48de26b87c88af005c2bf815e57b## <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Outer Row -->
    <div class="row justify-content-center">

        <div class="col-xl-10 col-lg-12 col-md-9">

            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row">
                        <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
                        <div class="col-lg-6">
                            <div class="p-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4"><?php echo e(__('messages.login')); ?></h1>
                                </div>
                                <form class="user" method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <?php if($errors->has('email')): ?>
                                            <div class="alert alert-danger" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                            </div>
                                        <?php endif; ?>
                                            <?php if($errors->has('name')): ?>
                                                <div class="alert alert-danger" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                                </div>>
                                            <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <input type="email" class="form-control form-control-user<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="<?php echo e(__('messages.email')); ?>">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control form-control-user<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required placeholder="<?php echo e(__('messages.password')); ?>">
                                    </div>
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox small">
                                            <input type="checkbox" class="custom-control-input" id="customCheck">
                                            <label class="custom-control-label" for="customCheck"><?php echo e(__('messages.rememberme')); ?></label>
                                        </div>
                                    </div>
                                    <input type="submit" class="btn btn-primary btn-user btn-block" value="<?php echo e(__('messages.login')); ?>">

                                    <hr>
                                    <a href="/auth/redirect/google" class="btn btn-google btn-user btn-block">
                                        <i class="fab fa-google fa-fw"></i> <?php echo e(__('messages.googlelogin')); ?>

                                    </a>
                                    <a href="/auth/redirect/facebook" class="btn btn-facebook btn-user btn-block">
                                        <i class="fab fa-facebook-f fa-fw"></i> <?php echo e(__('messages.facebooklogin')); ?>

                                    </a>
                                </form>
                                <hr>
                                <div class="text-center">
                                    <a class="small" href="<?php echo e(route('password.request')); ?>"><?php echo e(__('messages.forgotpwd')); ?></a>
                                </div>
                                <div class="text-center">
                                    <a class="small" href="<?php echo e(route('register')); ?>"><?php echo e(__('messages.register')); ?></a>
                                </div>
                                <div class="text-center">
                                    <a class="small" href="<?php echo e(url('locale/en')); ?>" ><img src="<?php echo e(asset('img/flag/us.png')); ?> "> English</a>
                                    <a class="small" href="<?php echo e(url('locale/th')); ?>" ><img src="<?php echo e(asset('img/flag/th.png')); ?> "> ไทย</a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>