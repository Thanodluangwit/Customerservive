<?php $__env->startSection('pageTitle'); ?><?php echo e(__('messages.chanenameserver')); ?> <?php echo e($domain_name); ?> ##parent-placeholder-6b4ea802132b48de26b87c88af005c2bf815e57b## <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-8 offset-2">
            <div class="card shadow mb-8">
                <div class="card-header ">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('messages.chanenameserver')); ?> <?php echo e($domain_name); ?></h6>
                </div>
                <div class="card-body ">
                    <form class="col-lg-6 offset-3 navbar-search" action="<?php echo e(route('update.dns')); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        <div class="input-group">
                            <input type="hidden" class="form-control bg-light border-0 small" name="domain" value="<?php echo e($domain_name); ?>"  required>
                        </div>
                        <div class="input-group">
                            <label class="col-form-label small"> NS1 : </label>
                            <input type="text" class="form-control bg-light border-0 small" placeholder="ns1 " name="ns_1" value="<?php echo e($ns1); ?>"  required>
                        </div>
                        <div class="input-group">
                            <label class="col-form-label small"> NS2 : </label>
                            <input type="text" class="form-control bg-light border-0 small" placeholder="ns2 " name="ns_2" value="<?php echo e($ns2); ?>" required>
                        </div>
                        <div class="input-group">
                            <label class="col-form-label small"> NS3 : </label>
                            <input type="text" class="form-control bg-light border-0 small" placeholder="ns3 " name="ns_3" value="<?php echo e($ns3); ?>">
                        </div>
                        <div class="input-group">
                            <label class="col-form-label small"> NS4 : </label>
                            <input type="text" class="form-control bg-light border-0 small" placeholder="ns4 " name="ns_4" value="<?php echo e($ns4); ?>"  >
                        </div>
                        <div class="input-group">
                        <input type="submit" class="btn btn-primary btn-user btn-block my-3" value="<?php echo e(__('messages.save')); ?>">

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>