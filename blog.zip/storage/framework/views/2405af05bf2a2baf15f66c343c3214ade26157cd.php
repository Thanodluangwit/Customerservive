<?php $__env->startSection('pageTitle'); ?><?php echo e(__('messages.dnsrecord')); ?><?php echo e($domain); ?> ##parent-placeholder-6b4ea802132b48de26b87c88af005c2bf815e57b## <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow mb12">
                <div class="card-header ">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('messages.dnsrecord')); ?> <?php echo e($domain); ?></h6>
                </div>
                <div class="card-body col-md-12">
                    <form class="col-lg-6 offset-3 navbar-search" action="<?php echo e(route('update.dns')); ?>" method="post">
                        <?php echo csrf_field(); ?>


                            <?php $__currentLoopData = $getdns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-row">
                                <div class="col-auto">
                                    <div class="input-group ">
                                        <input type="hidden" name="dnsrecid[]" value="<?php echo e($data['recid']); ?>" />
                                        <input type="text" class="form-control" name="dnsrecordhost[]"  placeholder="<?php echo e(__('messages.hostname')); ?>" value="<?php echo e($data['hostname']); ?>">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><?php echo e($domain); ?> </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <select name="dnsrecordtype[]" class="form-control">
                                        <option value="A">A (Address)</option>
                                        <option value="AAAA">AAAA (Address)</option>
                                        <option value="MX">MX (Mail)</option>
                                        <option value="CNAME">CNAME (Alias)</option>
                                        <option value="TXT">SPF (txt)</option>

                                    </select>
                                </div>
                                <div class="col">
                                    <input type="text" class="form-control" name="dnsrecordaddress[]" placeholder="<?php echo e(__('messages.ipaddress')); ?>" value="<?php echo e($data['address']); ?>">
                                </div>
                                <div class="col">
                                    <input type="text" class="form-control" name="dnsrecordpriority[]" placeholder="<?php echo e(__('messages.priority')); ?>">
                                    <label class="col-form-label-sm text-danger">สำหรับ MX</label>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--  -->
                        <div class="form-row">
                            <div class="col-auto">
                                <div class="input-group ">
                                    <input type="hidden" name="dnsrecid[]" value="" />
                                    <input type="text" class="form-control" name="dnsrecordhost[]"  placeholder="<?php echo e(__('messages.hostname')); ?>">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text"><?php echo e($domain); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <select name="dnsrecordtype[]" class="form-control">
                                    <option value="A">A (Address)</option>
                                    <option value="AAAA">AAAA (Address)</option>
                                    <option value="MX">MX (Mail)</option>
                                    <option value="CNAME">CNAME (Alias)</option>
                                    <option value="TXT">SPF (txt)</option>

                                </select>
                            </div>
                            <div class="col">
                                <input type="text" class="form-control" name="dnsrecordaddress[]" placeholder="<?php echo e(__('messages.ipaddress')); ?>">
                            </div>
                            <div class="col">
                                <input type="text" class="form-control" name="dnsrecordpriority[]" placeholder="<?php echo e(__('messages.priority')); ?>">
                                <label class="col-form-label-sm text-danger">สำหรับ MX</label>
                            </div>
                        </div>
                        <!--  -->
                        <div class="input-group">
                            <input type="submit" class="btn btn-primary btn-user btn-block my-3" value="<?php echo e(__('messages.save')); ?>">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>