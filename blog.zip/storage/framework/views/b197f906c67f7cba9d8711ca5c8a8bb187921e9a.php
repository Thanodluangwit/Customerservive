<?php $__env->startSection('pageTitle'); ?><?php echo e(__('messages.domainlist')); ?> ##parent-placeholder-6b4ea802132b48de26b87c88af005c2bf815e57b## <?php $__env->stopSection(); ?>
<?php $__env->startSection('domain'); ?> active ##parent-placeholder-9120580e94f134cb7c9f27cd1e43dbc82980e152## <?php $__env->stopSection(); ?>
<?php $__env->startSection('domainall'); ?> active ##parent-placeholder-2364656234815fd305cf06bff595dfdef657c2ca## <?php $__env->stopSection(); ?>
<?php $__env->startSection('domainshow'); ?> show ##parent-placeholder-f963b6fe6e347440d3ea8c42c91bfcf880c0d6ea## <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-8 offset-2">
            <div class="card shadow mb-8">
                <div class="card-header ">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('messages.domainlist')); ?></h6>
                </div>
                <div class="card-body ">
                    <div class="table-responsive">
                        <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th><?php echo e(__('messages.domain')); ?></th>
                                <th><?php echo e(__('messages.registrar')); ?></th>
                                <th><?php echo e(__('messages.regisdate')); ?></th>
                                <th><?php echo e(__('messages.expdate')); ?></th>
                                <th><?php echo e(__('messages.action')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $domain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($data->domain); ?></td>
                                <td><?php echo e($data->provider); ?></td>
                                <td><?php echo e($data->regis_date); ?></td>
                                <td><?php echo e($data->expire_date); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <?php echo e(__('messages.action')); ?>

                                        </button>
                                        <div class="dropdown-menu animated--fade-in" aria-labelledby="dropdownMenuButton">
                                            <?php if($data->provider == "T.H.NIC"): ?>
                                            <a class="dropdown-item" href="<?php echo e(url('/client/update_DNS_')); ?><?php echo e($data->domain); ?>"><?php echo e(__('messages.chanenameserver')); ?></a>
                                            <a class="dropdown-item" href="<?php echo e(url('client/Add_DNS_Record_')); ?><?php echo e($data->domain); ?>"><?php echo e(__('messages.dnsrecord')); ?></a>
                                            <a class="dropdown-item" href="#"><?php echo e(__('messages.domaincontact')); ?></a>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>