@extends('layouts.logincss')

@section('content')
<div class="container">  
    <div class="row">
          <div class="content">
              <img src="{{ asset('img/pz.png') }}" width="300px" >
                 <div class="title m-b-md">
                    403 Forbidden
                </div>
                <div class="subtitle m-b-md">
                    ทำไมเป็น <font color="red" > <b>ลูกค้า</b> </font> ที่เสือกจัง!
                </div>
              <div class="subtitle2 m-b-md">
                    #CEO สุดหล่อ ^^
                </div>

        </div>    
         
      
        </div>

@endsection
